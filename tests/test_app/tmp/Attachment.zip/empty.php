<?php
namespace App\Controller;

use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Network\Response;

class AttachmentsController extends AppController {

/**
 * BeforeFilter handle.
 *
 * @param Event $event The beforeFilter event that was fired.
 *
 * @return void
 */
	public function beforeFilter(Event $event) {
		parent::beforeFilter($event);

		$this->Auth->allow();
	}

/**
 * Download an attachment realated to an article.
 *
 * @return \Cake\Network\Response
 */
	public function download() {

		/*$this->response->file(
			'D:\Dropbox\Sites\Xeta\webroot\upload\blog\attachment\3\Empty.zip',
			['download' => true, 'name' => 'Empty.zip']
		);*/
		
		$za = new \ZipArchive();
		$za->open('D:\Dropbox\Sites\Xeta\webroot\upload\blog\attachment\3\Empty.zip');
		debug($za);die();

		//return $this->response;
	}
}
